#!/system/bin/sh
if [ ! -e /data/update_recovery ]; then
  if applypatch -c MTD:recovery:2048:b194d6f26fa7f0b0608420a962505b0e187fc2ee; then
    log -t recovery "Recovery image already installed"
    exit 0
  fi
fi

log -t recovery "Installing new recovery image"
echo start > /data/update_recovery
sync
if applypatch MTD:boot:4194304:cb696eaac1b12d85a1072e907562f049060ee537 MTD:recovery 5bcd521e1c91424d6dc6b5d245b5534a86357106 5242880 cb696eaac1b12d85a1072e907562f049060ee537:/system/recovery-from-boot.p; then
  rm /data/update_recovery
fi
