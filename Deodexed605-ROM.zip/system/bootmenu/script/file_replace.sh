#!/system/bootmenu/binary/busybox ash

rm /newboot/init.mapphone_cdma.rc
mv /newboot/init.mapphone_cdma.rc.new /newboot/init.mapphone_cdma.rc
chmod 750 /newboot/init.mapphone_cdma.rc

