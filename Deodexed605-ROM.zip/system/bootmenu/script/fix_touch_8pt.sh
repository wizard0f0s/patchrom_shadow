#!/system/bootmenu/binary/busybox ash

cp -f /system/bootmenu/fixes/09multitouch-8pt /system/etc/init.d/09multitouch

chmod 750 /system/etc/init.d/09multitouch

